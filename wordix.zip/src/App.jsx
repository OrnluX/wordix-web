import Game from './pages/Game'

export default function App() {
  return <Game />
}
