export default function GameHeader() {
  return (
    <header className="text-center mb-6">
      <h1 className="text-4xl font-bold mb-2">Wordix Web</h1>
    </header>
  )
}
